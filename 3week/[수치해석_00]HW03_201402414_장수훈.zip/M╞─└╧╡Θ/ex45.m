function s = small
a = 1;
while (1)
  s = a/2;
  if s==0,break,end
  a = s;
end
s = a;
endfunction
